--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.1
-- Dumped by pg_dump version 9.5.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.char_text_values DROP CONSTRAINT fk_textvals_2;
ALTER TABLE ONLY public.char_text_values DROP CONSTRAINT fk_textvals_1;
ALTER TABLE ONLY public.orders_items DROP CONSTRAINT fk_orders_items2;
ALTER TABLE ONLY public.orders_items DROP CONSTRAINT fk_orders_items;
ALTER TABLE ONLY public.orders DROP CONSTRAINT fk_orders;
ALTER TABLE ONLY public.char_float_values DROP CONSTRAINT fk_items_float_vals;
ALTER TABLE ONLY public.items DROP CONSTRAINT fk_id_type;
ALTER TABLE ONLY public.char_float_values DROP CONSTRAINT fk_chars_float;
ALTER TABLE ONLY public.chars DROP CONSTRAINT fk_characteristics_itemtype;
ALTER TABLE ONLY public.users_paydata DROP CONSTRAINT fk_card_owner;
DROP TRIGGER item_to_order_trig ON public.orders_items;
DROP INDEX public.und_users_email;
DROP INDEX public.int_float_vals;
DROP INDEX public.ind_users_uname;
DROP INDEX public.ind_text_vals;
DROP INDEX public.ind_item_type;
DROP INDEX public.ind_item_id;
DROP INDEX public.ind_cardnum_carddate;
ALTER TABLE ONLY public.users DROP CONSTRAINT uniq_users;
ALTER TABLE ONLY public.users DROP CONSTRAINT uniq_email_usr;
ALTER TABLE ONLY public.users_paydata DROP CONSTRAINT pk_paydata;
ALTER TABLE ONLY public.orders_items DROP CONSTRAINT pk_orders_items;
ALTER TABLE ONLY public.orders DROP CONSTRAINT pk_orders;
ALTER TABLE ONLY public.item_types DROP CONSTRAINT pk_item_types;
ALTER TABLE ONLY public.users DROP CONSTRAINT pk_id_user;
ALTER TABLE ONLY public.items DROP CONSTRAINT pk_id_item;
ALTER TABLE ONLY public.char_float_values DROP CONSTRAINT pk_float_values;
ALTER TABLE ONLY public.chars DROP CONSTRAINT pk_characteristics;
ALTER TABLE ONLY public.char_text_values DROP CONSTRAINT pk_char_text_vals;
DROP TABLE public.users_paydata;
DROP TABLE public.users;
DROP SEQUENCE public.users_id_user_seq;
DROP SEQUENCE public.user_groups_id_group_seq;
DROP VIEW public.text_chars;
DROP TABLE public.orders_items;
DROP TABLE public.orders;
DROP SEQUENCE public.orders_id_order_seq;
DROP TABLE public.items;
DROP SEQUENCE public.items_id_item_seq;
DROP TABLE public.item_types;
DROP SEQUENCE public.item_types_id_item_type_seq;
DROP VIEW public.float_chars;
DROP TABLE public.chars;
DROP SEQUENCE public.chars_id_char_seq;
DROP TABLE public.char_text_values;
DROP TABLE public.char_float_values;
DROP FUNCTION public.item_to_order_trg();
DROP FUNCTION public.grant_permissions(uname character varying, newperm character varying);
DROP FUNCTION public.get_permissons(uname character varying);
DROP FUNCTION public.create_user(ulog character varying, upass character varying, umail character varying, cardnum character varying, date character varying, uname character varying, usur character varying, umid character varying, ugrop character varying);
DROP FUNCTION public.authorize(log character varying, pass character);
DROP EXTENSION pgcrypto;
DROP EXTENSION plpgsql;
DROP SCHEMA system;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: system; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA system;


ALTER SCHEMA system OWNER TO postgres;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET search_path = public, pg_catalog;

--
-- Name: authorize(character varying, character); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION authorize(log character varying, pass character) RETURNS boolean
    LANGUAGE plpgsql COST 1
    AS $$
declare
	up char(64);
BEGIN
IF log != '' AND pass != '' THEN
	SELECT password_user into up FROM users WHERE login_user = log;
	RETURN pass = up;
ELSE
	RETURN false;
END IF;
END;
$$;


ALTER FUNCTION public.authorize(log character varying, pass character) OWNER TO postgres;

--
-- Name: create_user(character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION create_user(ulog character varying, upass character varying, umail character varying, cardnum character varying, date character varying, uname character varying, usur character varying, umid character varying, ugrop character varying) RETURNS void
    LANGUAGE plpgsql
    AS $_$
  BEGIN
    EXECUTE ' CREATE USER ' || quote_ident($1) || ' PASSWORD ' || quote_literal($2) ; 
    execute 'GRANT ' || quote_ident(ugrop) || ' TO ' || quote_ident($1) ;
    EXECUTE ' INSERT INTO users(login_user, email_user, password_user, reg_date_user) VALUES (''' || $1 || ''', ''' || $3 || ''', ''' || $2 || ''', ''' || now() || ''')';
    EXECUTE ' INSERT INTO users_paydata VALUES( ' || quote_literal($4) || ', ' || quote_literal(date) || ', (SELECT id_user FROM users WHERE login_user = ' || quote_literal($1) || '), ' || quote_literal(uname) || ', ' || quote_literal(usur) || ', ' || quote_literal(umid) || ')';
END;
$_$;


ALTER FUNCTION public.create_user(ulog character varying, upass character varying, umail character varying, cardnum character varying, date character varying, uname character varying, usur character varying, umid character varying, ugrop character varying) OWNER TO postgres;

--
-- Name: get_permissons(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION get_permissons(uname character varying) RETURNS character varying
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
  DECLARE
    uid INT4;
    rol VARCHAR(64);
  BEGIN
    SELECT (pg_catalog.pg_user.usesysid) INTO uid
    FROM pg_catalog.pg_user
    WHERE pg_catalog.pg_user.usename = quote_ident(uname);

    SELECT (pg_catalog.pg_group.groname) INTO rol
    FROM pg_catalog.pg_group
    WHERE uid = ANY (pg_catalog.pg_group.grolist);

    --RETURN uid;
    RETURN rol;
  END;
$$;


ALTER FUNCTION public.get_permissons(uname character varying) OWNER TO postgres;

--
-- Name: grant_permissions(character varying, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION grant_permissions(uname character varying, newperm character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  prevperm VARCHAR(64);
BEGIN
  SELECT (get_permissons(quote_ident(uname))) INTO prevperm;

  EXECUTE 'REVOKE ' || quote_ident(prevperm) || ' FROM ' || quote_ident(uname);
  EXECUTE 'GRANT ' || quote_ident(newperm) || ' TO ' || quote_ident(uname);
END;
  $$;


ALTER FUNCTION public.grant_permissions(uname character varying, newperm character varying) OWNER TO postgres;

--
-- Name: item_to_order_trg(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION item_to_order_trg() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE itmc BIGINT;
  BEGIN
    SELECT item_count FROM orders_items WHERE id_order = NEW.id_order AND id_item = NEW.id_item INTO itmc;
    IF itmc > 0 THEN
      UPDATE orders_items SET item_count = item_count+new.item_count
      WHERE id_order = NEW.id_order AND id_item = NEW.id_item;
      RETURN NULL;
    END IF;
    RETURN NEW;
  END;
$$;


ALTER FUNCTION public.item_to_order_trg() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: char_float_values; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE char_float_values (
    id_char bigint NOT NULL,
    id_item bigint NOT NULL,
    value double precision NOT NULL,
    char_units character varying(64)
);


ALTER TABLE char_float_values OWNER TO postgres;

--
-- Name: char_text_values; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE char_text_values (
    id_char bigint NOT NULL,
    id_item bigint NOT NULL,
    value character varying(64) NOT NULL,
    char_units character varying(64),
    CONSTRAINT chk_text_val_nnull CHECK (((value)::text <> ''::text))
);


ALTER TABLE char_text_values OWNER TO postgres;

--
-- Name: chars_id_char_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE chars_id_char_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE chars_id_char_seq OWNER TO postgres;

--
-- Name: chars; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE chars (
    id_char bigint DEFAULT nextval('chars_id_char_seq'::regclass) NOT NULL,
    name_char character varying(64) NOT NULL,
    id_item_owner_type bigint NOT NULL,
    CONSTRAINT "chk_name_Char" CHECK (((name_char)::text <> ''::text))
);


ALTER TABLE chars OWNER TO postgres;

--
-- Name: float_chars; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW float_chars AS
 SELECT char_float_values.id_item,
    chars.id_char,
    chars.name_char,
    char_float_values.value,
    char_float_values.char_units
   FROM (char_float_values
     JOIN chars ON ((char_float_values.id_char = chars.id_char)));


ALTER TABLE float_chars OWNER TO postgres;

--
-- Name: item_types_id_item_type_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE item_types_id_item_type_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE item_types_id_item_type_seq OWNER TO postgres;

--
-- Name: item_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE item_types (
    id_item_type bigint DEFAULT nextval('item_types_id_item_type_seq'::regclass) NOT NULL,
    name_type_item character varying(64) NOT NULL,
    CONSTRAINT chk_name_type CHECK (((name_type_item)::text <> ''::text))
);


ALTER TABLE item_types OWNER TO postgres;

--
-- Name: items_id_item_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE items_id_item_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE items_id_item_seq OWNER TO postgres;

--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE items (
    id_item bigint DEFAULT nextval('items_id_item_seq'::regclass) NOT NULL,
    type_id_item bigint NOT NULL,
    name_item character varying(64) NOT NULL,
    price_item_usd double precision NOT NULL,
    count_in_storage_item bigint NOT NULL,
    CONSTRAINT chk_count_items CHECK ((count_in_storage_item >= 0)),
    CONSTRAINT chk_item_name CHECK (((name_item)::text <> ''::text)),
    CONSTRAINT chk_price CHECK ((price_item_usd > (0)::double precision))
);


ALTER TABLE items OWNER TO postgres;

--
-- Name: orders_id_order_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE orders_id_order_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE orders_id_order_seq OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE orders (
    id_order bigint DEFAULT nextval('orders_id_order_seq'::regclass) NOT NULL,
    id_customer bigint NOT NULL,
    order_date date NOT NULL,
    paid boolean DEFAULT true NOT NULL
);


ALTER TABLE orders OWNER TO postgres;

--
-- Name: orders_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE orders_items (
    id_order bigint NOT NULL,
    id_item bigint NOT NULL,
    item_count integer NOT NULL,
    CONSTRAINT chk_item_count CHECK ((item_count > 0))
);


ALTER TABLE orders_items OWNER TO postgres;

--
-- Name: text_chars; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW text_chars AS
 SELECT char_text_values.id_item,
    chars.id_char,
    chars.name_char,
    char_text_values.value,
    char_text_values.char_units
   FROM (char_text_values
     JOIN chars ON ((char_text_values.id_char = chars.id_char)));


ALTER TABLE text_chars OWNER TO postgres;

--
-- Name: user_groups_id_group_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE user_groups_id_group_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE user_groups_id_group_seq OWNER TO postgres;

--
-- Name: users_id_user_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE users_id_user_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_id_user_seq OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE users (
    id_user bigint DEFAULT nextval('users_id_user_seq'::regclass) NOT NULL,
    login_user character varying(64) NOT NULL,
    email_user character varying(64) NOT NULL,
    password_user character(64) NOT NULL,
    reg_date_user date NOT NULL,
    CONSTRAINT chk_users_email CHECK (((email_user)::text ~ '^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+[.][A-Za-z]+$'::text)),
    CONSTRAINT chk_users_uname CHECK (((login_user)::text <> ''::text))
);


ALTER TABLE users OWNER TO postgres;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE users IS 'Table contains users auth data';


--
-- Name: users_paydata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE users_paydata (
    card_number character(16) NOT NULL,
    card_expire_date date NOT NULL,
    card_owner_id bigint NOT NULL,
    name_owner character varying(64),
    surname_owner character varying(64),
    middlename_owner character varying(64),
    CONSTRAINT chk_paydata_card_number CHECK ((card_number ~ '[0-9]{13,16}'::text))
);


ALTER TABLE users_paydata OWNER TO postgres;

--
-- Data for Name: char_float_values; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY char_float_values (id_char, id_item, value, char_units) FROM stdin;
\.
COPY char_float_values (id_char, id_item, value, char_units) FROM '$$PATH$$/2263.dat';

--
-- Data for Name: char_text_values; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY char_text_values (id_char, id_item, value, char_units) FROM stdin;
\.
COPY char_text_values (id_char, id_item, value, char_units) FROM '$$PATH$$/2259.dat';

--
-- Data for Name: chars; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY chars (id_char, name_char, id_item_owner_type) FROM stdin;
\.
COPY chars (id_char, name_char, id_item_owner_type) FROM '$$PATH$$/2258.dat';

--
-- Name: chars_id_char_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('chars_id_char_seq', 6, true);


--
-- Data for Name: item_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY item_types (id_item_type, name_type_item) FROM stdin;
\.
COPY item_types (id_item_type, name_type_item) FROM '$$PATH$$/2256.dat';

--
-- Name: item_types_id_item_type_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('item_types_id_item_type_seq', 7, true);


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY items (id_item, type_id_item, name_item, price_item_usd, count_in_storage_item) FROM stdin;
\.
COPY items (id_item, type_id_item, name_item, price_item_usd, count_in_storage_item) FROM '$$PATH$$/2254.dat';

--
-- Name: items_id_item_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('items_id_item_seq', 3, true);


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY orders (id_order, id_customer, order_date, paid) FROM stdin;
\.
COPY orders (id_order, id_customer, order_date, paid) FROM '$$PATH$$/2261.dat';

--
-- Name: orders_id_order_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('orders_id_order_seq', 7, true);


--
-- Data for Name: orders_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY orders_items (id_order, id_item, item_count) FROM stdin;
\.
COPY orders_items (id_order, id_item, item_count) FROM '$$PATH$$/2262.dat';

--
-- Name: user_groups_id_group_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('user_groups_id_group_seq', 1, false);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users (id_user, login_user, email_user, password_user, reg_date_user) FROM stdin;
\.
COPY users (id_user, login_user, email_user, password_user, reg_date_user) FROM '$$PATH$$/2251.dat';

--
-- Name: users_id_user_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('users_id_user_seq', 5, true);


--
-- Data for Name: users_paydata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users_paydata (card_number, card_expire_date, card_owner_id, name_owner, surname_owner, middlename_owner) FROM stdin;
\.
COPY users_paydata (card_number, card_expire_date, card_owner_id, name_owner, surname_owner, middlename_owner) FROM '$$PATH$$/2252.dat';

--
-- Name: pk_char_text_vals; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY char_text_values
    ADD CONSTRAINT pk_char_text_vals PRIMARY KEY (id_item, id_char);


--
-- Name: pk_characteristics; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY chars
    ADD CONSTRAINT pk_characteristics PRIMARY KEY (id_char);


--
-- Name: pk_float_values; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY char_float_values
    ADD CONSTRAINT pk_float_values PRIMARY KEY (id_char, id_item);


--
-- Name: pk_id_item; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY items
    ADD CONSTRAINT pk_id_item PRIMARY KEY (id_item);


--
-- Name: pk_id_user; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT pk_id_user PRIMARY KEY (id_user);


--
-- Name: pk_item_types; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY item_types
    ADD CONSTRAINT pk_item_types PRIMARY KEY (id_item_type);


--
-- Name: pk_orders; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT pk_orders PRIMARY KEY (id_order);


--
-- Name: pk_orders_items; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders_items
    ADD CONSTRAINT pk_orders_items PRIMARY KEY (id_order, id_item);


--
-- Name: pk_paydata; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users_paydata
    ADD CONSTRAINT pk_paydata PRIMARY KEY (card_number, card_expire_date);


--
-- Name: uniq_email_usr; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT uniq_email_usr UNIQUE (email_user);


--
-- Name: uniq_users; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT uniq_users UNIQUE (login_user);


--
-- Name: ind_cardnum_carddate; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ind_cardnum_carddate ON users_paydata USING btree (card_number, card_expire_date) WITH (fillfactor='90');


--
-- Name: ind_item_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ind_item_id ON items USING btree (id_item) WITH (fillfactor='90');


--
-- Name: ind_item_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ind_item_type ON items USING btree (type_id_item) WITH (fillfactor='90');


--
-- Name: ind_text_vals; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ind_text_vals ON char_text_values USING btree (id_item, id_char) WITH (fillfactor='90');


--
-- Name: ind_users_uname; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ind_users_uname ON users USING btree (login_user) WITH (fillfactor='90');


--
-- Name: int_float_vals; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX int_float_vals ON char_float_values USING btree (id_item, id_char) WITH (fillfactor='90');


--
-- Name: und_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX und_users_email ON users USING btree (email_user) WITH (fillfactor='90');


--
-- Name: item_to_order_trig; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER item_to_order_trig BEFORE INSERT ON orders_items FOR EACH ROW EXECUTE PROCEDURE item_to_order_trg();


--
-- Name: fk_card_owner; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users_paydata
    ADD CONSTRAINT fk_card_owner FOREIGN KEY (card_owner_id) REFERENCES users(id_user) MATCH FULL ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fk_characteristics_itemtype; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY chars
    ADD CONSTRAINT fk_characteristics_itemtype FOREIGN KEY (id_item_owner_type) REFERENCES item_types(id_item_type) MATCH FULL ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fk_chars_float; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY char_float_values
    ADD CONSTRAINT fk_chars_float FOREIGN KEY (id_char) REFERENCES chars(id_char) MATCH FULL ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fk_id_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY items
    ADD CONSTRAINT fk_id_type FOREIGN KEY (type_id_item) REFERENCES item_types(id_item_type) MATCH FULL ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fk_items_float_vals; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY char_float_values
    ADD CONSTRAINT fk_items_float_vals FOREIGN KEY (id_item) REFERENCES items(id_item) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_orders; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT fk_orders FOREIGN KEY (id_customer) REFERENCES users(id_user) MATCH FULL ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fk_orders_items; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders_items
    ADD CONSTRAINT fk_orders_items FOREIGN KEY (id_order) REFERENCES orders(id_order) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_orders_items2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orders_items
    ADD CONSTRAINT fk_orders_items2 FOREIGN KEY (id_item) REFERENCES items(id_item) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_textvals_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY char_text_values
    ADD CONSTRAINT fk_textvals_1 FOREIGN KEY (id_item) REFERENCES items(id_item) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk_textvals_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY char_text_values
    ADD CONSTRAINT fk_textvals_2 FOREIGN KEY (id_char) REFERENCES chars(id_char) MATCH FULL ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: authorize(character varying, character); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION authorize(log character varying, pass character) FROM PUBLIC;
REVOKE ALL ON FUNCTION authorize(log character varying, pass character) FROM postgres;
GRANT ALL ON FUNCTION authorize(log character varying, pass character) TO postgres;
GRANT ALL ON FUNCTION authorize(log character varying, pass character) TO PUBLIC;
GRANT ALL ON FUNCTION authorize(log character varying, pass character) TO admin;


--
-- Name: char_float_values; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE char_float_values FROM PUBLIC;
REVOKE ALL ON TABLE char_float_values FROM postgres;
GRANT ALL ON TABLE char_float_values TO postgres;
GRANT ALL ON TABLE char_float_values TO admin WITH GRANT OPTION;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE char_float_values TO seller;
GRANT SELECT ON TABLE char_float_values TO "user";


--
-- Name: char_text_values; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE char_text_values FROM PUBLIC;
REVOKE ALL ON TABLE char_text_values FROM postgres;
GRANT ALL ON TABLE char_text_values TO postgres;
GRANT ALL ON TABLE char_text_values TO admin WITH GRANT OPTION;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE char_text_values TO seller;
GRANT SELECT ON TABLE char_text_values TO "user";


--
-- Name: chars; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE chars FROM PUBLIC;
REVOKE ALL ON TABLE chars FROM postgres;
GRANT ALL ON TABLE chars TO postgres;
GRANT ALL ON TABLE chars TO admin WITH GRANT OPTION;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE chars TO seller;
GRANT SELECT ON TABLE chars TO "user";


--
-- Name: item_types; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE item_types FROM PUBLIC;
REVOKE ALL ON TABLE item_types FROM postgres;
GRANT ALL ON TABLE item_types TO postgres;
GRANT ALL ON TABLE item_types TO admin WITH GRANT OPTION;
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE item_types TO seller;
GRANT SELECT ON TABLE item_types TO "user";


--
-- Name: items; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE items FROM PUBLIC;
REVOKE ALL ON TABLE items FROM postgres;
GRANT ALL ON TABLE items TO postgres;
GRANT SELECT,INSERT,UPDATE ON TABLE items TO admin;


--
-- Name: orders_id_order_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE orders_id_order_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE orders_id_order_seq FROM postgres;
GRANT ALL ON SEQUENCE orders_id_order_seq TO postgres;
GRANT ALL ON SEQUENCE orders_id_order_seq TO admin;


--
-- Name: orders; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE orders FROM PUBLIC;
REVOKE ALL ON TABLE orders FROM postgres;
GRANT ALL ON TABLE orders TO postgres;
GRANT ALL ON TABLE orders TO admin WITH GRANT OPTION;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE orders TO "user";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE orders TO seller;


--
-- Name: orders_items; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE orders_items FROM PUBLIC;
REVOKE ALL ON TABLE orders_items FROM postgres;
GRANT ALL ON TABLE orders_items TO postgres;
GRANT ALL ON TABLE orders_items TO admin WITH GRANT OPTION;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE orders_items TO "user";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE orders_items TO seller;


--
-- Name: text_chars; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE text_chars FROM PUBLIC;
REVOKE ALL ON TABLE text_chars FROM postgres;
GRANT ALL ON TABLE text_chars TO postgres;
GRANT SELECT,INSERT,UPDATE ON TABLE text_chars TO admin;


--
-- Name: users; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE users FROM PUBLIC;
REVOKE ALL ON TABLE users FROM postgres;
GRANT ALL ON TABLE users TO postgres;
GRANT ALL ON TABLE users TO admin WITH GRANT OPTION;
GRANT SELECT ON TABLE users TO "user";


--
-- Name: users_paydata; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE users_paydata FROM PUBLIC;
REVOKE ALL ON TABLE users_paydata FROM postgres;
GRANT ALL ON TABLE users_paydata TO postgres;
GRANT ALL ON TABLE users_paydata TO admin WITH GRANT OPTION;
GRANT SELECT ON TABLE users_paydata TO seller;
GRANT SELECT ON TABLE users_paydata TO "user";


--
-- PostgreSQL database dump complete
--

